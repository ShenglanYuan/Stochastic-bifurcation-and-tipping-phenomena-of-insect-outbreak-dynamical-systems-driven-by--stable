clear;
clc;

Nx=1000;
x1=linspace(0,20,Nx);
funright=x1./(1+x1.^2);

r=0.4;
k=9.5;
x2=linspace(0,k,Nx);
funleft=r*(1-x2/k);

x=linspace(0,8,Nx);
VF=r*x.*(1-x/k)-x.^2./(1+x.^2);
% funx=@(t)t.^2./(1+t.^2)-r*t.*(1-t/k);
% Ux=zeros(1,Nx);
% for i=2:Nx
%     Ux(i)=integral(funx,x(1),x(i));
% end
% 
% figure;
% plot(x,Ux);

figure;
plot(x1,funright);
hold on
plot(x2,funleft);
hold off

figure;
plot(x,VF);
hold on
plot([0 8],[0 0]);
hold off


x1=linspace(1.02,20,Nx);
k1=2*x1.^3./(x1.^2-1);
r1=2*x1.^3./(x1.^2+1).^2;

figure;
plot(k1,r1);
