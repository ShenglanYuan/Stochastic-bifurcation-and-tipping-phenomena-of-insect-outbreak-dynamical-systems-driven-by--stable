clear;
clc;

%%% parameters
zmin=0;
zmax=8;
J=100;
v=linspace(-2,2,4*J+1);
v(1)=[];
v(end)=[];
h=v(2)-v(1);
deltat=2e-3;
nT=1e5;
sigma=0.02;
alpha=0.8;
Calpha=alpha*gamma((1+alpha)/2)/(2^(1-alpha)*sqrt(pi)*gamma(1-alpha/2));
sigmaB=0;
Ch=sigmaB/2-sigma^alpha*Calpha*zeta(alpha-1)*h^(2-alpha);
C1=Ch/h^2;
C2=Calpha/alpha*(2*sigma/(zmax-zmin))^alpha;
C3=Calpha*(2*sigma/(zmax-zmin))^alpha*h;

%%% initialization
P=zeros(2*J-1,nT+1);
P(:,1)=normpdf(v(J+1:3*J-1),0,0.05);
A1=zeros(2*J-1,2*J-1);
for i=1:2*J-1
    A1(i,:)=1./abs(v(2*J+1-i:4*J-1-i)).^(1+alpha);
    A1(i,i)=0;
end
v1=0.5./abs(v(1:2*J-1)).^(1+alpha);
v2=0.5./abs(v(2*J+1:4*J-1)).^(1+alpha);
v1=flipud(v1);
v2=flipud(v2);
A0=[v1' A1 v2'];
for i=1:2*J-1
    A1(i,i)=-sum(A0(i,:));
end
A1=C3*A1;
v0=C2./(1+v(J+1:3*J-1)).^alpha+C2./(1-v(J+1:3*J-1)).^alpha;
A1=A1-2*C1*eye(2*J-1)-diag(v0);
A1(1:2*J-2,2:2*J-1)=A1(1:2*J-2,2:2*J-1)+C1*eye(2*J-2);
A1(2:2*J-1,1:2*J-2)=A1(2:2*J-1,1:2*J-2)+C1*eye(2*J-2);

%%% drift
x=(zmax-zmin)/2*v(J+1:3*J-1)+(zmax+zmin)/2;
x=x';
% r=0.649506;
% k=5.19637;
r=0.4;
k=9.5;
fx=r*x.*(1-x/k)-x.^2./(1+x.^2);
Mf=max(abs(fx));

%%% integral
for i=1:nT
    U=P(:,i);
    phi=(fx+Mf).*U/2;
    phixp=2/(zmax-zmin)*leftbiased(phi,h);
    phi=(fx-Mf).*U/2;
    phixn=2/(zmax-zmin)*rightbiased(phi,h);
    U1=U+deltat*(A1*U-phixp-phixn);
    
    phi=(fx+Mf).*U1/2;
    phixp=2/(zmax-zmin)*leftbiased(phi,h);
    phi=(fx-Mf).*U1/2;
    phixn=2/(zmax-zmin)*rightbiased(phi,h);
    U2=3/4*U+1/4*U1+deltat/4*(A1*U1-phixp-phixn);
    
    phi=(fx+Mf).*U2/2;
    phixp=2/(zmax-zmin)*leftbiased(phi,h);
    phi=(fx-Mf).*U2/2;
    phixn=2/(zmax-zmin)*rightbiased(phi,h);
    P(:,i+1)=1/3*U+2/3*U2+deltat*2/3*(A1*U2-phixp-phixn);
end

figure;
plot(x,P(:,50001));

t=(0:nT)*deltat;
[T,X]=meshgrid(t,x);
figure;
mesh(T,X,P);

